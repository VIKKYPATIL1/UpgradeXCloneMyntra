import 'package:flutter/material.dart';
import 'package:myntra_insider_clone/screen/home.dart';

void main() {
  runApp(MaterialApp(
    theme: ThemeData().copyWith(
        useMaterial3: true,
        scaffoldBackgroundColor: Color.fromARGB(255, 19, 12, 26)),
    home: const Home(),
  ));
}
