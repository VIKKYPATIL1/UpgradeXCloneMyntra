import 'package:flutter/material.dart';

class CardW extends StatelessWidget {
  const CardW(
      {super.key,
      required this.headingOne,
      required this.subtitleOne,
      required this.headingTwo});
  final String headingOne;
  final String subtitleOne;
  final String headingTwo;
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 80,
      child: Card(
        color: Color.fromARGB(255, 47, 41, 54),
        shape:
            ContinuousRectangleBorder(borderRadius: BorderRadius.circular(10)),
        child: Row(
          children: [
            Image.asset('assets/images/p1.png'),
            const SizedBox(
              width: 20,
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  headingOne,
                  style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                      color: Colors.white),
                ),
                const SizedBox(
                  height: 10,
                ),
                Text(
                  subtitleOne,
                  style: const TextStyle(fontSize: 15, color: Colors.white),
                )
              ],
            ),
            // const SizedBox(
            //   width: 160,
            // ),
            const Spacer(),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  headingTwo,
                  style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 20,
                      color: Colors.white),
                ),
                const SizedBox(
                  height: 10,
                ),
                const Text(
                  'Goal',
                  style: TextStyle(fontSize: 15, color: Colors.white),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
