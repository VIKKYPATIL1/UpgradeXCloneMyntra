import 'package:flutter/material.dart';

class BenefitW extends StatelessWidget {
  const BenefitW({super.key});
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Benefits Of Joining the Program',
          style: TextStyle(
              color: Color.fromARGB(255, 255, 174, 0),
              fontSize: 25,
              fontWeight: FontWeight.bold),
        ),
        const SizedBox(
          height: 30,
        ),
        Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Image.asset('assets/images/x1.png'),
            const SizedBox(
              width: 10,
            ),
            const Text('Early Access to The Sale',
                style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.white))
          ],
        ),
        const SizedBox(
          height: 10,
        ),
        Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Image.asset('assets/images/x2.png'),
            const SizedBox(
              width: 10,
            ),
            const Text(
                'Insider Exclusive Rewards \n'
                '& Benefits',
                style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.white))
          ],
        ),
        const SizedBox(
          height: 10,
        ),
        Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Image.asset('assets/images/x3.png'),
            const SizedBox(
              width: 10,
            ),
            const Text('Priority Customer Support',
                style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.white))
          ],
        )
      ],
    );
  }
}
