import 'package:flutter/material.dart';

class Rewards extends StatelessWidget {
  const Rewards({super.key});
  @override
  Widget build(context) {
    List<String> data = [
      'Get Myntra Voucher worth Rs.500',
      "Get Levi's Voucher worth Rs. 500",
      "Get SonyLiv Premium 1 Month Subscription",
      "Get Tokyo Talkies Voucher worth Rs.400",
      "Get FLAT 12% OFF on Flipkart Flight  Bookings"
    ];
    return SizedBox(
        height: 300,
        child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: [
              for (int i = 1; i <= 5; i++)
                Card(
                  child: Stack(children: [
                    Image.asset('assets/images/l$i.png'),
                    Positioned(
                        height: 70,
                        bottom: 0,
                        left: 3,
                        right: 3,
                        child: Text(
                          data[i - 1],
                          style: const TextStyle(
                              fontSize: 15, fontWeight: FontWeight.bold),
                        ))
                  ]),
                )
            ],
          ),
        ));
  }
}
