import 'package:flutter/material.dart';

class HeadingPage extends StatelessWidget {
  const HeadingPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          gradient: LinearGradient(colors: [
        Color.fromARGB(255, 19, 12, 26),
        Color.fromARGB(255, 19, 12, 26).withOpacity(0.6)
      ], begin: Alignment.bottomCenter, end: Alignment.topCenter)),
      height: 500,
      child: Stack(
        children: [
          Image.asset('assets/images/h1.png'),
          const Positioned(
            height: 150,
            bottom: 0,
            left: 0,
            right: 0,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Become An INSIDER!',
                  style: TextStyle(
                      color: Color.fromARGB(255, 255, 174, 0),
                      fontSize: 25,
                      fontWeight: FontWeight.bold),
                ),
                SizedBox(
                  height: 20,
                ),
                Text(
                  'Join the Insider programme and earn'
                  'Supercoins with every purchase and much'
                  'more. Log in now!',
                  style: TextStyle(
                      color: Color.fromARGB(156, 255, 254, 246), fontSize: 20),
                )
              ],
            ),
          ),
        ],
      ),
    );
  }
}
