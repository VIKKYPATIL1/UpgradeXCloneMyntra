import 'package:flutter/material.dart';
import 'package:myntra_insider_clone/widgets/benifitw.dart';
import 'package:myntra_insider_clone/widgets/card.dart';
import 'package:myntra_insider_clone/widgets/heading.dart';
import 'package:myntra_insider_clone/widgets/rewards.dart';
import 'package:myntra_insider_clone/widgets/workpage.dart';

class ListViewPage extends StatelessWidget {
  const ListViewPage({super.key});
  @override
  Widget build(BuildContext context) {
    return ListView(
      children: [
        const HeadingPage(),
        const SizedBox(
          height: 10,
        ),
        const Text(
          'New Goal Criteria',
          style: TextStyle(
              color: Color.fromARGB(255, 255, 254, 246),
              fontSize: 25,
              fontWeight: FontWeight.bold),
        ),
        const SizedBox(
          height: 10,
        ),
        const CardW(
            headingOne: '₹0', subtitleOne: "You've Spent", headingTwo: '₹7000'),
        const CardW(
          headingOne: '0/5',
          subtitleOne: 'Your Orders',
          headingTwo: '5',
        ),
        const SizedBox(
          height: 10,
        ),
        Text(
          'Note: Recent purchases only reflect in goal once the'
          ' return window is over',
          style: TextStyle(color: Colors.white.withOpacity(0.5)),
        ),
        const SizedBox(
          height: 30,
        ),
        const BenefitW(),
        const SizedBox(
          height: 30,
        ),
        const WorkPage(),
        const SizedBox(
          height: 30,
        ),
        Rewards(),
      ],
    );
  }
}
