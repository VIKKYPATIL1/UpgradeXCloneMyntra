import 'package:flutter/material.dart';

class WorkPage extends StatelessWidget {
  const WorkPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'How Does It Work',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Color.fromARGB(255, 255, 174, 0),
          ),
        ),
        const SizedBox(
          height: 30,
        ),
        Text(
          'Earn a SuperCoin with every purchase\n'
          'You can get upto 3 SuperCoin for every ₹100 spents',
          style: TextStyle(
            color: Colors.white.withOpacity(0.5),
          ),
        ),
        const SizedBox(
          height: 30,
        ),
        Image.asset('assets/images/h2.png'),
      ],
    );
  }
}
