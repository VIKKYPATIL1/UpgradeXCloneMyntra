import 'package:flutter/material.dart';

class StackW extends StatelessWidget {
  const StackW(
      {super.key,
      required this.type,
      required this.priceTag,
      required this.image});
  final String type;
  final String priceTag;
  final String image;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Image.asset(image),
        Positioned(
          height: 70,
          left: 0,
          right: 0,
          bottom: 0,
          child: Container(
              alignment: Alignment.centerLeft,
              decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [
                Color.fromARGB(255, 200, 141, 189).withOpacity(0.2),
                Color.fromARGB(255, 220, 54, 193).withOpacity(1),
              ], begin: Alignment.bottomCenter, end: Alignment.topCenter)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    type,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 20,
                        color: Color.fromARGB(255, 12, 12, 12)),
                  ),
                  Text(
                    priceTag,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 25,
                        color: Color.fromARGB(255, 254, 254, 254)),
                  ),
                ],
              )),
        ),
      ],
    );
  }
}
