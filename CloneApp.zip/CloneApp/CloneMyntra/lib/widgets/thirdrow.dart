import 'package:flutter/material.dart';
import 'package:myntra_clone/widgets/stackw.dart';

class ThirdRow extends StatelessWidget {
  const ThirdRow({super.key});
  @override
  Widget build(BuildContext context) {
    return const Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          'DEAL OF THE DAY',
          style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
        ),
        SizedBox(
          height: 300,
          width: 200,
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                StackW(
                    type: 'Kurtas',
                    priceTag: 'under 899',
                    image: 'assets/images/q1.png'),
                StackW(
                    type: 'Dresses',
                    priceTag: 'under 899',
                    image: 'assets/images/q2.png'),
                StackW(
                    type: 'Work-Ready-Shoes',
                    priceTag: 'Min 30% off',
                    image: 'assets/images/q3.png'),
                StackW(
                    type: 'Casual Shoes & FlipFlop',
                    priceTag: 'Min 60% off',
                    image: 'assets/images/q4.png'),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
