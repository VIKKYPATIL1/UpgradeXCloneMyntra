import 'package:flutter/material.dart';

class FirstRow extends StatelessWidget {
  const FirstRow({super.key});
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 200,
      width: 400,
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: [
          Image.asset(
            "assets/images/p2.png",
            fit: BoxFit.cover,
            height: 200,
            width: 400,
          ),
          Image.asset(
            "assets/images/p3.png",
            fit: BoxFit.cover,
            height: 200,
            width: 400,
          ),
          Image.asset(
            "assets/images/p1.png",
            fit: BoxFit.cover,
            height: 200,
            width: 400,
          ),
        ],
      ),
    );
  }
}
