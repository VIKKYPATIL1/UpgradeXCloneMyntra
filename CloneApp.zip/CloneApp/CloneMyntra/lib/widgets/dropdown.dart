import 'package:flutter/material.dart';

class DropdownButtonW extends StatefulWidget {
  const DropdownButtonW({super.key});
  @override
  State<DropdownButtonW> createState() {
    return _DropdownButtonWState();
  }
}

class _DropdownButtonWState extends State<DropdownButtonW> {
  String _selectedItem = 'MEN';

  final List<String> _items = [
    'MEN',
    'WOMEN',
    'KIDS',
    'HOME & LIVING',
    'BEAUTY',
    'STUDIO',
  ];

  @override
  Widget build(BuildContext context) {
    return Center(
      child: DropdownButton<String>(
        value: _selectedItem,
        onChanged: (String? newValue) {
          setState(() {
            _selectedItem = newValue!;
          });
        },
        items: _items.map<DropdownMenuItem<String>>((String value) {
          return DropdownMenuItem<String>(
            value: value,
            child: Text(value),
          );
        }).toList(),
        hint: const Text('Select Category'),
      ),
    );
  }
}
