import 'package:flutter/material.dart';
import 'package:myntra_clone/widgets/stackw.dart';

class SecondRow extends StatelessWidget {
  const SecondRow({super.key});
  @override
  Widget build(BuildContext context) {
    List<String> type = ['Stylish Picks', 'Kurta sets', 'Kurtas', 'Tops'];
    List<String> priceTag = ['Min 70% Offs', '₹ 699', '₹ 499', '₹ 299'];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'BEST OF MYNTRA EXCLUSIVE BRANDS',
          style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
        ),
        const SizedBox(
          height: 20,
        ),
        SizedBox(
          height: 400,
          width: double.maxFinite,
          child: GridView.builder(
            itemCount: 4,
            itemBuilder: (context, index) {
              return StackW(
                  type: type[index],
                  priceTag: priceTag[index],
                  image: 'assets/images/r${index + 1}.png');
            },
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2),
            scrollDirection: Axis.horizontal,
          ),
        ),
      ],
    );
  }
}
