import 'package:flutter/material.dart';
import 'package:myntra_clone/screens/home.dart';

void main() {
  runApp(
    MaterialApp(
      theme: ThemeData().copyWith(useMaterial3: true),
      home: const HomeScreen(),
    ),
  );
}
