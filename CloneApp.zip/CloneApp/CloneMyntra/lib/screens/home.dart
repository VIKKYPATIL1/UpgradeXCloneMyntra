import 'package:flutter/material.dart';
import 'package:myntra_clone/widgets/dropdown.dart';
import 'package:myntra_clone/widgets/firstrow.dart';
import 'package:myntra_clone/widgets/secondrow.dart';
import 'package:myntra_clone/widgets/thirdrow.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Image.asset(
          "assets/images/logo.png",
          fit: BoxFit.cover,
          height: 40,
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () {},
          ),
          const DropdownButtonW(),
          const Icon(Icons.perm_contact_calendar_rounded),
          const Icon(Icons.favorite),
          const Icon(Icons.card_travel_rounded)
        ],
      ),
      floatingActionButton: IconButton.filledTonal(
          onPressed: () {},
          icon:
              const Icon(Icons.add_alert_rounded, color: Colors.white, fill: 1),
          iconSize: 40),
      body: ListView(children: const [
        FirstRow(),
        SizedBox(
          height: 20,
        ),
        ThirdRow(),
        SizedBox(
          height: 20,
        ),
        SecondRow(),
      ]),
    );
  }
}
